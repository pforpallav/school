CPSC314 Assignment 2

Name:	Evan Louie
CSID:	m6d7
SID:	72210099

1.	All requirements up to but not including geosynchronous
		When pressing the g key:
			Cones will appear where the ships should go when in geosync mode and rotate properly with respect the rotation of the planet
			Camera shifting not complete
	All keys map to correct actions. (except keys having to do with geosynchronous orbit [1-9] and the reset button [m].)

BONUS:
	Impelmented Lighting
	

By submitting this ﬁle, I hereby declare that I worked individually on this assignment and that I am the
only author of this code. I have listed all external resoures (web pages, books) used below. I have listed all
people with whom I have had signiﬁcant discussions about the project below.