/*
 * directory.c
 *
 * Functions used to deal with directory entries.
 */


#include "directory.h"
