/*
 * wordio.c
 *
 * Low-level functions used to perform  operations on words (normally 1, 2 or
 * 4 bytes) contained in a buffer.
 */
#include "wordio.h"
