/*
 * Program to print information about a FAT file system.
 */

/*
 * Main function.
 */
int main(int argc, char *argv[])
{

}
