/*
 * fat12.c
 *
 */


#include "fat12.h"
