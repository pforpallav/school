/*
 * wordio.h
 *
 * Low-level functions used to perform  operations on words (normally 1, 2 or
 * 4 bytes) contained in a buffer.
 */

#ifndef WORDIO_H
#define WORDIO_H

/*
 *  Add stuff here
 */

#endif
