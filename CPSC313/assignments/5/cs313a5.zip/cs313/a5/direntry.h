/*
 * direntry.h
 *
 * Functions used to deal with directory entries.
 */

#ifndef DIRENTRY_H
#define DIRENTRY_H

/* Add stuff in here */

#endif
