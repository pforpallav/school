/*
 * direntry.c
 *
 * Functions used to deal with directory entries.
 */

#include "direntry.h"
