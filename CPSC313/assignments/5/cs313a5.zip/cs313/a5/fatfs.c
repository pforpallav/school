/*
 * fatfs.c
 *
 * Basic operations on a FAT filesystem.
 */

#include "fatfs.h"
