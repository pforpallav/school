Name:	Evan Louie
SID:	72210099
CSID:	m6d7
Email:	louie.evan@gmail.com